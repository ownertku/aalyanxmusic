<p align="center">
  <img src="AalyanXMusic/assets/equalizer.svg" width="100%" height="500">
</p>

<div align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&weight=700&size=34&duration=4500&pause=1000&color=00D9FF&center=true&vCenter=true&width=1600&lines=𝐀𝐚𝐥𝐲𝐚𝐧+𝐗+𝐌𝐮𝐬𝐢𝐜+𝐑𝐞𝐩𝐨+—+𝐋𝐢𝐠𝐡𝐭𝐭𝐧𝐢𝐧𝐠+𝐅𝐚𝐬𝐭+𝐌𝐮𝐬𝐢𝐜+𝐒𝐭𝐫𝐞𝐚𝐦𝐢𝐧𝐠+—+𝐍𝐨𝐰+𝐑𝐮𝐧𝐧𝐢𝐧𝐠+𝐨𝐧+𝐀𝐏𝐈!">
</div>

---

<div align="center">

## ⚡ 𝐍𝐨𝐰 𝐑𝐮𝐧𝐧𝐢𝐧𝐠 𝐨𝐧 𝐀𝐏𝐈 - 𝟏𝟎𝐱 𝐅𝐚𝐬𝐭𝐞𝐫! ⚡

> **𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞 𝐓𝐢𝐦𝐞:** `1-3 seconds` | **𝐒𝐭𝐚𝐛𝐢𝐥𝐢𝐭𝐲:** `99.9% Uptime`

[![Support Channel](https://img.shields.io/badge/Support%20Channel-black?style=for-the-badge&logo=telegram)](https://t.me/AalyanXMusic)
[![Support Group](https://img.shields.io/badge/Support%20Group-black?style=for-the-badge&logo=telegram)](https://t.me/AalyanXMusicSupport)
[![Owner](https://img.shields.io/badge/Owner-black?style=for-the-badge&logo=telegram)](https://t.me/WTF_WhyMeeh)

[![Forks](https://img.shields.io/github/forks/NoxxOP/AalyanXMusic?color=black&logo=github&logoColor=black&style=for-the-badge)](https://github.com/NoxxOP/AalyanXMusic/fork)
[![Stars](https://img.shields.io/github/stars/NoxxOP/AalyanXMusic?color=black&logo=github&logoColor=black&style=for-the-badge)](https://github.com/NoxxOP/AalyanXMusic/stargazers)
[![Contributors](https://img.shields.io/github/contributors/NoxxOP/AalyanXMusic?color=black&logo=github&logoColor=black&style=for-the-badge)](https://github.com/NoxxOP/AalyanXMusic/graphs/contributors)

</div>

---

## 🚀 𝐐𝐮𝐢𝐜𝐤 𝐃𝐞𝐩𝐥𝐨𝐲

<div align="center">

| **𝐏𝐥𝐚𝐭𝐟𝐨𝐫𝐦** | **𝐃𝐞𝐩𝐥𝐨𝐲 𝐍𝐨𝐰** | **𝐈𝐧𝐟𝐨** |
|:---:|:---:|:---:|
| **𝐇𝐞𝐫𝐨𝐤𝐮** | [![Deploy](https://img.shields.io/badge/Deploy%20On%20Heroku-black?style=for-the-badge&logo=heroku)](https://dashboard.heroku.com/new?template=https://github.com/NoxxOP/AalyanXMusic) | 𝐎𝐧𝐞-𝐂𝐥𝐢𝐜𝐤 𝐃𝐞𝐩𝐥𝐨𝐲 |
| **𝐑𝐞𝐧𝐝𝐞𝐫** | [![Deploy](https://img.shields.io/badge/Deploy%20On%20Render-black?style=for-the-badge&logo=render)](https://render.com/deploy?repo=https://github.com/NoxxOP/AalyanXMusic) | 𝟏𝟎𝟎% 𝐅𝐫𝐞𝐞 |
| **𝐒𝐢𝐦𝐩𝐥𝐞 𝐁𝐨𝐭** | [![View](https://img.shields.io/badge/Simple%20Bot-black?style=for-the-badge&logo=github)](https://github.com/NoxxOP/AalyanXMusic) | 𝐋𝐢𝐠𝐡𝐭𝐰𝐞𝐢𝐠𝐡𝐭 |

</div>

---

## ✨ 𝐅𝐞𝐚𝐭𝐮𝐫𝐞𝐬

<div align="center">

| 🎵 𝐇𝐢𝐠𝐡 𝐐𝐮𝐚𝐥𝐢𝐭𝐲 | 🔗 𝐌𝐮𝐥𝐭𝐢𝐩𝐥𝐞 𝐒𝐨𝐮𝐫𝐜𝐞𝐬 | 📋 𝐏𝐥𝐚𝐲𝐥𝐢𝐬𝐭𝐬 | 🌐 𝐌𝐮𝐥𝐭𝐢-𝐋𝐚𝐧𝐠𝐮𝐚𝐠𝐞 |
|:---:|:---:|:---:|:---:|
| Crystal clear audio | YouTube • Spotify | Create & Manage | Multiple Languages |
| **🎨 𝐄𝐥𝐞𝐠𝐚𝐧𝐭 𝐔𝐈** | **👑 𝐀𝐝𝐦𝐢𝐧 𝐂𝐨𝐧𝐭𝐫𝐨𝐥𝐬** | **⚡ 𝐋𝐢𝐠𝐡𝐭𝐧𝐢𝐧𝐠 𝐅𝐚𝐬𝐭** | **🔊 𝐒𝐭𝐚𝐛𝐥𝐞** |
| Modern Interface | Powerful Commands | 1-3s Response | 99.9% Uptime |

</div>

---

## 🎯 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬

<div align="center">

| 𝐂𝐨𝐦𝐦𝐚𝐧𝐝 | 𝐃𝐞𝐬𝐜𝐫𝐢𝐩𝐭𝐢𝐨𝐧 |
|:---:|:---:|
| `/play [song]` | 🎵 𝐏𝐥𝐚𝐲 𝐦𝐮𝐬𝐢𝐜 |
| `/pause` | ⏸️ 𝐏𝐚𝐮𝐬𝐞 𝐩𝐥𝐚𝐲𝐛𝐚𝐜𝐤 |
| `/resume` | ▶️ 𝐑𝐞𝐬𝐮𝐦𝐞 𝐩𝐥𝐚𝐲𝐛𝐚𝐜𝐤 |
| `/skip` | ⏭️ 𝐒𝐤𝐢𝐩 𝐭𝐫𝐚𝐜𝐤 |
| `/stop` | ⏹️ 𝐒𝐭𝐨𝐩 𝐩𝐥𝐚𝐲𝐛𝐚𝐜𝐤 |
| `/playlist` | 📋 𝐕𝐢𝐞𝐰 𝐩𝐥𝐚𝐲𝐥𝐢𝐬𝐭 |
| `/song [name]` | 📥 𝐃𝐨𝐰𝐧𝐥𝐨𝐚𝐝 𝐚𝐮𝐝𝐢𝐨 |
| `/settings` | ⚙️ 𝐁𝐨𝐭 𝐬𝐞𝐭𝐭𝐢𝐧𝐠𝐬 |

</div>

---

## 🚀 𝐃𝐞𝐩𝐥𝐨𝐲𝐦𝐞𝐧𝐭 𝐆𝐮𝐢𝐝𝐞

<details>
<summary><b>📦 𝐕𝐏𝐒 𝐃𝐞𝐩𝐥𝐨𝐲𝐦𝐞𝐧𝐭 (𝐂𝐥𝐢𝐜𝐤 𝐭𝐨 𝐄𝐱𝐩𝐚𝐧𝐝)</b></summary>

<br>

### **𝐒𝐭𝐞𝐩 𝟏: 𝐔𝐩𝐝𝐚𝐭𝐞 𝐒𝐲𝐬𝐭𝐞𝐦**

```bash
sudo apt-get update && sudo apt-get upgrade -y
```

---

### **𝐒𝐭𝐞𝐩 𝟐: 𝐈𝐧𝐬𝐭𝐚𝐥𝐥 𝐑𝐞𝐪𝐮𝐢𝐫𝐞𝐝 𝐏𝐚𝐜𝐤𝐚𝐠𝐞𝐬**

```bash
sudo apt-get install python3 python3-pip ffmpeg git screen curl -y
```

---

### **𝐒𝐭𝐞𝐩 𝟑: 𝐈𝐧𝐬𝐭𝐚𝐥𝐥 𝐍𝐨𝐝𝐞.𝐣𝐬**

```bash
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
```

```bash
sudo apt-get install -y nodejs
```

---

### **𝐒𝐭𝐞𝐩 𝟒: 𝐂𝐥𝐨𝐧𝐞 𝐑𝐞𝐩𝐨𝐬𝐢𝐭𝐨𝐫𝐲**

```bash
git clone https://github.com/NoxxOP/AalyanXMusic
```

```bash
cd AalyanXMusic
```

---

### **𝐒𝐭𝐞𝐩 𝟓: 𝐂𝐫𝐞𝐚𝐭𝐞 𝐒𝐜𝐫𝐞𝐞𝐧 𝐒𝐞𝐬𝐬𝐢𝐨𝐧**

```bash
screen
```

**𝐍𝐨𝐭𝐞:** Press `Ctrl+A` then `D` to detach screen

**𝐓𝐨 𝐑𝐞𝐚𝐭𝐭𝐚𝐜𝐡:**
```bash
screen -ls
```
```bash
screen -r {screen_id}
```

---

### **𝐒𝐭𝐞𝐩 𝟔: 𝐈𝐧𝐬𝐭𝐚𝐥𝐥 𝐕𝐢𝐫𝐭𝐮𝐚𝐥 𝐄𝐧𝐯𝐢𝐫𝐨𝐧𝐦𝐞𝐧𝐭 𝐏𝐚𝐜𝐤𝐚𝐠𝐞**

```bash
sudo apt-get install python3-venv -y
```

---

### **𝐒𝐭𝐞𝐩 𝟕: 𝐂𝐫𝐞𝐚𝐭𝐞 𝐕𝐢𝐫𝐭𝐮𝐚𝐥 𝐄𝐧𝐯𝐢𝐫𝐨𝐧𝐦𝐞𝐧𝐭**

```bash
python3 -m venv venv
```

```bash
source venv/bin/activate
```

---

### **𝐒𝐭𝐞𝐩 𝟖: 𝐈𝐧𝐬𝐭𝐚𝐥𝐥 𝐏𝐲𝐭𝐡𝐨𝐧 𝐃𝐞𝐩𝐞𝐧𝐝𝐞𝐧𝐜𝐢𝐞𝐬**

```bash
pip3 install -U pip
```

```bash
pip3 install -U -r requirements.txt
```

---

### **𝐒𝐭𝐞𝐩 𝟗: 𝐂𝐨𝐧𝐟𝐢𝐠𝐮𝐫𝐚𝐭𝐢𝐨𝐧**

```bash
nano .env
```

**𝐅𝐢𝐥𝐥 𝐢𝐧 𝐲𝐨𝐮𝐫 𝐯𝐚𝐫𝐢𝐚𝐛𝐥𝐞𝐬:**

- `API_ID` & `API_HASH` - Get from [my.telegram.org](https://my.telegram.org)
- `BOT_TOKEN` - Get from [@BotFather](https://t.me/BotFather)
- `MONGO_DB_URI` - MongoDB Atlas connection string
- `OWNER_ID` - Your Telegram user ID
- `STRING_SESSION` - Generate using [@Sessionbbbot](https://t.me/Sessionbbbot)
- `LOG_GROUP_ID` - Log group/channel ID (starting with -100)
- `SUPPORT_GROUP` - Your support group link
- `SUPPORT_CHANNEL` - Your support channel link

**Save:** `Ctrl+X` then `Y` then `Enter`

---

### **𝐒𝐭𝐞𝐩 𝟏𝟎: 𝐒𝐭𝐚𝐫𝐭 𝐁𝐨𝐭**

**𝐌𝐞𝐭𝐡𝐨𝐝 𝟏:**
```bash
python3 -m AalyanXMusic
```

**𝐌𝐞𝐭𝐡𝐨𝐝 𝟐:**
```bash
bash start
```

**𝐃𝐞𝐭𝐚𝐜𝐡 𝐒𝐜𝐫𝐞𝐞𝐧:** `Ctrl+A` then `D`

</details>

---

<details>
<summary><b>☁️ 𝐇𝐞𝐫𝐨𝐤𝐮 𝐃𝐞𝐩𝐥𝐨𝐲𝐦𝐞𝐧𝐭 (𝐂𝐥𝐢𝐜𝐤 𝐭𝐨 𝐄𝐱𝐩𝐚𝐧𝐝)</b></summary>

<br>

<div align="center">

[![Deploy to Heroku](https://img.shields.io/badge/Deploy%20To%20Heroku-black?style=for-the-badge&logo=heroku)](https://dashboard.heroku.com/new?template=https://github.com/NoxxOP/AalyanXMusic)

</div>

### **𝐒𝐭𝐞𝐩𝐬:**

1. Click the "Deploy To Heroku" button above
2. Fill in the required environment variables:
   - `API_ID` & `API_HASH` from [my.telegram.org](https://my.telegram.org)
   - `BOT_TOKEN` from [@BotFather](https://t.me/BotFather)
   - `MONGO_DB_URI` - MongoDB connection string
   - `STRING_SESSION` from [@Sessionbbbot](https://t.me/Sessionbbbot)
   - Other required variables
3. Click "Deploy App"
4. Go to Resources tab and enable the worker

</details>

---

<details>
<summary><b>🔄 𝐒𝐞𝐬𝐬𝐢𝐨𝐧 𝐒𝐭𝐫𝐢𝐧𝐠 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫 (𝐂𝐥𝐢𝐜𝐤 𝐭𝐨 𝐄𝐱𝐩𝐚𝐧𝐝)</b></summary>

<br>

<div align="center">

[![Session Bot](https://img.shields.io/badge/Session%20Generator-black?style=for-the-badge&logo=telegram)](https://t.me/Sessionbbbot)

</div>

### **𝐒𝐭𝐞𝐩𝐬:**

1. 🤖 Start [@Sessionbbbot](https://t.me/Sessionbbbot)
2. 📱 Send your phone number with country code
3. 🔢 Enter the OTP you receive
4. ✅ Copy your session string

</details>

---

<details>
<summary><b>🤔 𝐂𝐨𝐦𝐦𝐨𝐧 𝐈𝐬𝐬𝐮𝐞𝐬 (𝐂𝐥𝐢𝐜𝐤 𝐭𝐨 𝐄𝐱𝐩𝐚𝐧𝐝)</b></summary>

<br>

| **𝐈𝐬𝐬𝐮𝐞** | **𝐒𝐨𝐥𝐮𝐭𝐢𝐨𝐧** |
|:---:|:---:|
| Bot not responding | Check if bot is running with proper permissions |
| No sound in VC | Ensure FFmpeg is properly installed |
| Can't join voice chat | Make bot admin with VC permissions |
| API issues | Double check `API_ID` and `API_HASH` |
| Slow response | Check internet connection and server resources |

</details>

---

## 📊 𝐒𝐭𝐚𝐭𝐬

<div align="center">

![Repo Size](https://img.shields.io/github/repo-size/NoxxOP/AalyanXMusic?color=black&logo=github&logoColor=black&style=for-the-badge)
![Issues](https://img.shields.io/github/issues/NoxxOP/AalyanXMusic?color=black&logo=github&logoColor=black&style=for-the-badge)
![License](https://img.shields.io/github/license/NoxxOP/AalyanXMusic?color=black&logo=github&logoColor=black&style=for-the-badge)
![Last Commit](https://img.shields.io/github/last-commit/NoxxOP/AalyanXMusic?color=blue&logo=github&logoColor=green&style=for-the-badge)

</div>

---

## 🌟 𝐂𝐫𝐞𝐝𝐢𝐭𝐬

<div align="center">

**𝐌𝐚𝐢𝐧 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫**

[![NoxxOP](https://img.shields.io/badge/NoxxOP-black?style=for-the-badge&logo=github)](https://github.com/NoxxOP)

**𝐒𝐩𝐞𝐜𝐢𝐚𝐥 𝐓𝐡𝐚𝐧𝐤𝐬 𝐭𝐨 𝐀𝐥𝐥 𝐂𝐨𝐧𝐭𝐫𝐢𝐛𝐮𝐭𝐨𝐫𝐬**

</div>

---

## 📝 𝐋𝐢𝐜𝐞𝐧𝐬𝐞

<div align="center">

[![MIT License](https://img.shields.io/badge/License-MIT-blueviolet?style=for-the-badge)](LICENSE)

</div>

---

## 💬 𝐒𝐮𝐩𝐩𝐨𝐫𝐭

<div align="center">

| **𝐒𝐮𝐩𝐩𝐨𝐫𝐭 𝐂𝐡𝐚𝐧𝐧𝐞𝐥** | **𝐒𝐮𝐩𝐩𝐨𝐫𝐭 𝐆𝐫𝐨𝐮𝐩** |
|:---:|:---:|
| [![Channel](https://img.shields.io/badge/Join%20Channel-black?style=for-the-badge&logo=telegram)](https://t.me/AalyanXMusic) | [![Group](https://img.shields.io/badge/Join%20Group-black?style=for-the-badge&logo=telegram)](https://t.me/AalyanXMusicSupport) |
| Latest Updates | 24/7 Help & Support |

---

<img src="https://img.shields.io/badge/Made%20with%20%E2%9D%A4%EF%B8%8F%20by-NoxxOP-orange?style=for-the-badge&logo=heart" alt="Made with love">

---

<p align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=22&duration=3000&pause=1000&color=00D9FF&center=true&vCenter=true&width=600&lines=Fast+%F0%9F%9A%80+Reliable+%F0%9F%94%92+High+Quality+%F0%9F%8E%B5;10x+Faster+with+API+%E2%9A%A1;Join+Our+Community+%F0%9F%92%AC" alt="Typing SVG">
</p>

</div>

